package be.kdg.paint.model;

import java.util.ArrayList;
import java.util.List;

public class Painting {
	private List<Component> components=new ArrayList<>();

	public List<Component> getComponents(){
		return components;
	}

	// methods with business logic


}
