open module question2FX {
    requires javafx.controls;
    requires javafx.media;
}