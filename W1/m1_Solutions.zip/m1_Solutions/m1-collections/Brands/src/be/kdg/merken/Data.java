package be.kdg.merken;

public class Data {
	public final static String[] merken = {
		"BMW", "Audi", "VW", "Ford", "Opel",
		"Renault", "Peugeot", "Citroen", "Mercedes", "Fiat"
	};
}
