package be.kdg.prog12.collections;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * Author: Jan de Rijke
 */
public class Names {

	public static void main(String[] args) {
		ArrayList<String> names = new ArrayList<>();
		names.add("Albert");
		names.add("Henry");
		names.add("Josephine");
		names.add("Annabelle");
		names.add("Ashraf");
		//print first:
		System.out.println(names.get(0));
		//print last:
		System.out.println(names.get(names.size() - 1));
		//for each :
		System.out.print("All names: ");
		for (String naam : names) {
			System.out.print(naam + " ");
		}
		//Is Georgie in the list?
		System.out.println("\nGeorgie :" + names.contains("Georgie"));

		//Remove all names starting with A
		//Use an iterator!
		//for each is read-only!!!
		Iterator<String> it = names.iterator();
		while (it.hasNext()) {
			if (it.next().startsWith("A")) {
				it.remove();
			}
		}

		//Print again
		System.out.print("Selected names: ");
		System.out.println(names);
	}
}

