package be.kdg.prog12.colections;

/**
 * Author: Jan de Rijke
 */
public class Runner {
	public static void main(String[] args) {
		Menu menu = new Menu();
		menu.addDrink(new Drink("LaChouffe",3.5,true));
		menu.addDrink(new Drink("Coca Cola",2,false));
		menu.addDrink(new Drink("Spa Sparkling",2,false));
		menu.addDrink(new Drink("Spa Still",2,false));
		menu.addDrink(new Drink("Coca Cola Light",2,false));
		menu.addDrink(new Drink("Coffee",2.5,false));
		menu.addDrink(new Drink("Tea",2.5,false));
		menu.addDrink(new Drink("Pils",2,true));
		menu.addDrink(new Drink("Duvel",3.5,true));
		menu.addDrink(new Drink("Orval",4,true));

		System.out.printf("Our menu contains %d drinks, with a total cost of €%.2f\n",menu.getSize(),menu.sumPrices());
		System.out.println( menu);
		System.out.println("Our most expensive drink is: " + menu.mostExpensive());
		System.out.println("Our alcoholic drinks are: " + menu.getAlcoholicDrinks());
		menu.removeMoreExpensiveThen(3);
		System.out.println("Menu without drinks above €3: " + menu);
		Drink[] newArrivals = {new Drink("Bushmills 10yr",7,true),new Drink("SpringBank 5yr", 5,true)};
		menu.addDrinks(newArrivals);
		System.out.println("Extended menu: "+menu);
		menu.sort();
		System.out.println("Sorted menu: "+menu);



	}
}
