package be.kdg.drivers;

import java.util.Objects;
import java.util.SortedSet;

/**
 * Author: Jan de Rijke
 */
public class Driver implements Comparable<Driver>{
	private String country;
	private String name;
	private SortedSet<Integer> seasons;
	public Driver( String name, String country,SortedSet<Integer> seasons) {
		this.country=country;
		this.name=name;
		this.seasons=seasons;
	}

	public String getCountry() {
		return country;
	}

	public String getName() {
		return name;
	}

	public SortedSet<Integer> getSeasons() {
		return seasons;
	}

	@Override
	public String toString() {
		return String.format ("%s (%s) %d times champion %s",name,country,seasons.size(),seasons);
	}

	@Override
	public int compareTo(Driver o) {
		int seasondiff =  o.seasons.size()-seasons.size();
		return seasondiff == 0?seasons.first()-o.seasons.first():seasondiff;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (!(o instanceof Driver)) return false;
		Driver driver = (Driver) o;
		return name.equals(driver.name);
	}

	@Override
	public int hashCode() {
		return Objects.hash(name);
	}
}
