package be.kdg.drivers;

import java.util.*;

/**
 * Author: Jan de Rijke
 */
public class Drivers {
	private Map<String, Driver> driversByName = new HashMap<>();
	private Map<Integer, Driver> driversByYear = new HashMap<>();


	public Drivers(String[][] champions, Integer[][] years) {
		for (int champion = 0; champion < champions.length; champion++) {
			Driver driver = new Driver(champions[champion][1],
				champions[champion][0],
				new TreeSet<> (Set.of(years[champion])));
			driversByName.put(driver.getName(), driver);
			for (int year = 0; year < years[champion].length; year++) {
				driversByYear.put(years[champion][year], driver);
			}
		}
	}

	public Driver getDriverByName(String name) {
		return driversByName.get(name);
	}

	public Collection <Driver> getDrivers(){
		return driversByName.values();
	}

	public Driver getChampion(int year) {
		return driversByYear.get(year);
	}


}
