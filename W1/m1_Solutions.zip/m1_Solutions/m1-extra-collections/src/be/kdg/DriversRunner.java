package be.kdg;

import be.kdg.drivers.Driver;
import be.kdg.drivers.Drivers;

import java.util.Set;
import java.util.TreeSet;

/**
 * Author: Jan de Rijke
 */
public class DriversRunner {

	private static String[][] champions = {
		{"Germany", "Michael Schumacher"},
		{"Argentina", "Juan Manuel Fangio"},
		{"France", "Alain Prost"},
		{"German", "Sebastian Vettel"},
		{"Australia", "Jack Brabham"},
		{"United Kingdom", "Jackie Stewart"},
		{"Austria", "Niki Lauda"},
		{"Brasil", "Nelson Piquet"},
		{"Brasil", "Ayrton Senna"},
		{"United Kingdom","Lewis Hamilton"}
	};

	private static Integer[][] years = {
		{1994, 1995, 2000, 2001, 2002, 2003, 2004},
		{1951, 1954, 1955, 1956, 1957},
		{1985, 1986, 1989, 1993},
		{2010, 2011, 2012, 2013},
		{1959, 1960, 1966},
		{1969, 1971, 1973},
		{1975, 1977, 1984},
		{1981, 1983, 1987},
		{1988, 1990, 1991},
		{2008,2014,2015,2017,2018,2019,2020}
	};

	public static void main(String[] args) {
		Drivers drivers = new Drivers(champions,years);
		System.out.println(drivers.getDriverByName("Jackie Stewart"));
		printChampion( drivers,2000);
		printChampion( drivers,2005);
		System.out.println("\nDRIVERS BY TITLES");
		Set<Driver> sortedDrivers = new TreeSet<>(drivers.getDrivers());
		for (Driver sortedDriver : sortedDrivers) {
			System.out.println(sortedDriver);
		}
	}

	private static void printChampion(Drivers drivers,int year) {
		Driver champion = drivers.getChampion(year);
		System.out.printf("%d champion: %s\n" ,year,(champion == null )? "not listed" : champion.getName());
	}


}

/*
  Jackie Stewart (United Kingdom) 3 times champion [1969, 1971, 1973]
	2000 champion: Michael Schumacher
	2005 champion: not listed
	[Sebastian Vettel (German) 4 times champion [2010, 2011, 2012, 2013], Alain Prost (France) 4 times champion [1985, 1986, 1989, 1993], Jack Brabham (Australia) 3 times champion [1959, 1960, 1966], Niki Lauda (Austria) 3 times champion [1975, 1977, 1984], Juan Manuel Fangio (Argentina) 5 times champion [1951, 1954, 1955, 1956, 1957], Jackie Stewart (United Kingdom) 3 times champion [1969, 1971, 1973], Lewis Hamilton (United Kingdom) 7 times champion [2008, 2014, 2015, 2017, 2018, 2019, 2020], Michael Schumacher (Germany) 7 times champion [1994, 1995, 2000, 2001, 2002, 2003, 2004], Ayrton Senna (Brasil) 3 times champion [1988, 1990, 1991], Nelson Piquet (Brasil) 3 times champion [1981, 1983, 1987]]
	Drivers by titles
	Ayrton Senna (Brasil) 3 times champion [1988, 1990, 1991]
	Jack Brabham (Australia) 3 times champion [1959, 1960, 1966]
	Jackie Stewart (United Kingdom) 3 times champion [1969, 1971, 1973]
	Nelson Piquet (Brasil) 3 times champion [1981, 1983, 1987]
	Niki Lauda (Austria) 3 times champion [1975, 1977, 1984]
	Alain Prost (France) 4 times champion [1985, 1986, 1989, 1993]
	Sebastian Vettel (German) 4 times champion [2010, 2011, 2012, 2013]
	Juan Manuel Fangio (Argentina) 5 times champion [1951, 1954, 1955, 1956, 1957]
	Lewis Hamilton (United Kingdom) 7 times champion [2008, 2014, 2015, 2017, 2018, 2019, 2020]
	Michael Schumacher (Germany) 7 times champion [1994, 1995, 2000, 2001, 2002, 2003, 2004]*/
